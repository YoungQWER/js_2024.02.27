package com.product.dto;




import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
public class BankAccountVO {
	private String bankName;
	private String accountNum;
	

}
	
	
	
	


